// E-mail via Resend API — sem npm, usa fetch nativo do Node 18
// Env: RESEND_API_KEY  →  obter grátis em resend.com (3000 emails/mês)
//      EMAIL_DESTINO   →  padrão: suporte@softtiinformatica.com.br

exports.handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json",
  };

  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers, body: "" };
  if (event.httpMethod !== "POST")    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };

  const KEY    = process.env.RESEND_API_KEY;
  const TO     = process.env.EMAIL_DESTINO || "suporte@softtiinformatica.com.br";
  const FROM   = "SoftTur CRM <onboarding@resend.dev>";

  if (!KEY) return {
    statusCode: 500, headers,
    body: JSON.stringify({ error: "Configure RESEND_API_KEY no Netlify → Environment variables (grátis em resend.com)" })
  };

  let body;
  try { body = JSON.parse(event.body); }
  catch (e) { return { statusCode: 400, headers, body: JSON.stringify({ error: "JSON inválido" }) }; }

  const { tipo, cliente, comentario, data, cadastro, totalMensal, totalSetup,
          taskId, titulo, status, prioridade, responsavel, departamento, prazo, descricao, criadoPor } = body;
  const cad = cadastro || {};

  let subject = "", html = "";

  // ── PROPOSTA RECUSADA ──────────────────────────────────────────────────────
  if (tipo === "recusado") {
    subject = `❌ PROPOSTA RECUSADA — ${cliente}`;
    html = `<div style="font-family:Arial,sans-serif;max-width:580px;margin:0 auto">
      <div style="background:#DC2626;padding:20px 24px;border-radius:8px 8px 0 0">
        <h2 style="color:#fff;margin:0;font-size:20px">❌ Proposta Recusada</h2>
        <p style="color:rgba(255,255,255,.8);margin:4px 0 0;font-size:13px">${data || ""}</p>
      </div>
      <div style="background:#fff;padding:20px 24px;border:1px solid #e5e7eb;border-top:none;border-radius:0 0 8px 8px">
        <table style="width:100%;border-collapse:collapse;font-size:14px">
          <tr><td style="padding:8px 0;color:#6b7280;width:40%">Cliente</td><td style="font-weight:700">${cliente || "-"}</td></tr>
          <tr><td style="padding:8px 0;color:#6b7280">Total Mensal</td><td style="font-weight:700;color:#DC2626">${totalMensal || "-"}</td></tr>
          <tr><td style="padding:8px 0;color:#6b7280">Total Setup</td><td style="font-weight:600">${totalSetup || "-"}</td></tr>
          ${comentario ? `<tr><td style="padding:8px 0;color:#6b7280;vertical-align:top">Comentário</td><td style="font-style:italic">"${comentario}"</td></tr>` : ""}
        </table>
        <p style="margin:16px 0 0;font-size:13px;color:#6b7280;background:#FEF2F2;padding:12px;border-radius:6px">
          ⚡ Entre em contato com o cliente para entender os motivos e renegociar.
        </p>
      </div>
    </div>`;
  }

  // ── PROPOSTA APROVADA ──────────────────────────────────────────────────────
  if (tipo === "aprovado") {
    const gerentes = (cad.gerentes || []).filter(g => g.nome)
      .map(g => `<tr>
        <td style="padding:6px 0;color:#6b7280;vertical-align:top">${g.cargo || "Gerente"}</td>
        <td><strong>${g.nome}</strong>${g.email ? ` &middot; ${g.email}` : ""}${g.telefone ? ` &middot; ${g.telefone}` : ""}</td>
      </tr>`).join("") || "<tr><td colspan='2' style='color:#9ca3af;padding:6px 0'>Não informado</td></tr>";

    subject = `✅ PROPOSTA APROVADA — ${cliente} — Cadastro recebido`;
    html = `<div style="font-family:Arial,sans-serif;max-width:580px;margin:0 auto">
      <div style="background:#16A34A;padding:20px 24px;border-radius:8px 8px 0 0">
        <h2 style="color:#fff;margin:0;font-size:20px">✅ Proposta Aprovada!</h2>
        <p style="color:rgba(255,255,255,.8);margin:4px 0 0;font-size:13px">${data || ""}</p>
      </div>
      <div style="background:#fff;padding:20px 24px;border:1px solid #e5e7eb;border-top:none;border-radius:0 0 8px 8px">
        <table style="width:100%;border-collapse:collapse;font-size:14px;margin-bottom:16px">
          <tr><td style="padding:6px 0;color:#6b7280;width:40%">Cliente</td><td style="font-weight:700;font-size:16px">${cliente || "-"}</td></tr>
          <tr><td style="padding:6px 0;color:#6b7280">Total Mensal</td><td style="font-weight:700;color:#16A34A">${totalMensal || "-"}</td></tr>
          <tr><td style="padding:6px 0;color:#6b7280">Total Setup</td><td style="font-weight:600">${totalSetup || "-"}</td></tr>
          ${comentario ? `<tr><td style="padding:6px 0;color:#6b7280;vertical-align:top">Comentário</td><td style="font-style:italic">"${comentario}"</td></tr>` : ""}
        </table>
        <hr style="border:none;border-top:1px solid #e5e7eb;margin:16px 0"/>
        <p style="font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:.05em;margin:0 0 8px">Responsável pelo Contrato</p>
        <table style="width:100%;border-collapse:collapse;font-size:14px;margin-bottom:16px">
          <tr><td style="padding:5px 0;color:#6b7280;width:40%">Nome</td><td><strong>${cad.nomeCompleto || "-"}</strong></td></tr>
          <tr><td style="padding:5px 0;color:#6b7280">CPF</td><td>${cad.cpf || "-"}</td></tr>
          <tr><td style="padding:5px 0;color:#6b7280">Telefone</td><td>${cad.telefone || "-"}</td></tr>
          <tr><td style="padding:5px 0;color:#6b7280">E-mail</td><td>${cad.email || "-"}</td></tr>
          <tr><td style="padding:5px 0;color:#6b7280">Estado Civil</td><td>${cad.estadoCivil || "-"}</td></tr>
          <tr><td style="padding:5px 0;color:#6b7280">Profissão</td><td>${cad.profissao || "-"}</td></tr>
        </table>
        <hr style="border:none;border-top:1px solid #e5e7eb;margin:16px 0"/>
        <p style="font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:.05em;margin:0 0 8px">Dados da Empresa</p>
        <table style="width:100%;border-collapse:collapse;font-size:14px;margin-bottom:16px">
          <tr><td style="padding:5px 0;color:#6b7280;width:40%">Razão Social</td><td>${cad.razaoSocial || "-"}</td></tr>
          <tr><td style="padding:5px 0;color:#6b7280">Nome Fantasia</td><td>${cad.nomeFantasia || "-"}</td></tr>
          <tr><td style="padding:5px 0;color:#6b7280">CNPJ</td><td><strong>${cad.cnpj || "-"}</strong></td></tr>
          <tr><td style="padding:5px 0;color:#6b7280">E-mail Financeiro</td><td>${cad.emailFinanceiro || "-"}</td></tr>
          <tr><td style="padding:5px 0;color:#6b7280">Tel. Financeiro</td><td>${cad.telefoneFinanceiro || "-"}</td></tr>
        </table>
        <hr style="border:none;border-top:1px solid #e5e7eb;margin:16px 0"/>
        <p style="font-size:12px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:.05em;margin:0 0 8px">Gerentes / Responsáveis</p>
        <table style="width:100%;border-collapse:collapse;font-size:14px">${gerentes}</table>
      </div>
    </div>`;
  }

  // ── TAREFA ─────────────────────────────────────────────────────────────────
  if (tipo === "tarefa") {
    subject = `📋 [TAREFA] ${taskId || ""} — ${titulo || ""}`;
    html = `<div style="font-family:Arial,sans-serif;max-width:580px;margin:0 auto">
      <div style="background:#111827;padding:20px 24px;border-radius:8px 8px 0 0">
        <p style="color:#9ca3af;margin:0 0 4px;font-size:12px">${taskId || ""}</p>
        <h2 style="color:#fff;margin:0;font-size:18px">${titulo || ""}</h2>
      </div>
      <div style="background:#fff;padding:20px 24px;border:1px solid #e5e7eb;border-top:none;border-radius:0 0 8px 8px">
        <table style="width:100%;border-collapse:collapse;font-size:14px">
          <tr><td style="padding:7px 0;color:#6b7280;width:40%">Status</td><td><strong>${status || "-"}</strong></td></tr>
          <tr><td style="padding:7px 0;color:#6b7280">Prioridade</td><td><strong>${prioridade || "-"}</strong></td></tr>
          <tr><td style="padding:7px 0;color:#6b7280">Responsável</td><td>${responsavel || "-"}</td></tr>
          <tr><td style="padding:7px 0;color:#6b7280">Departamento</td><td>${departamento || "-"}</td></tr>
          <tr><td style="padding:7px 0;color:#6b7280">Prazo</td><td>${prazo || "-"}</td></tr>
          <tr><td style="padding:7px 0;color:#6b7280">Criado por</td><td>${criadoPor || "-"}</td></tr>
          ${descricao ? `<tr><td style="padding:7px 0;color:#6b7280;vertical-align:top">Descrição</td><td style="white-space:pre-wrap">${descricao}</td></tr>` : ""}
        </table>
      </div>
    </div>`;
  }

  if (!subject) return { statusCode: 400, headers, body: JSON.stringify({ error: "Tipo inválido: " + tipo }) };

  try {
    const resp = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ from: FROM, to: [TO], subject, html }),
    });

    const result = await resp.json();

    if (resp.ok) return { statusCode: 200, headers, body: JSON.stringify({ ok: true, id: result.id }) };
    return { statusCode: resp.status, headers, body: JSON.stringify({ ok: false, error: result }) };
  } catch (e) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: e.message }) };
  }
};
