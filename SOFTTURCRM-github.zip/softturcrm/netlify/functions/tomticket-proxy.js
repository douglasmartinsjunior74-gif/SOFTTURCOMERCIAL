// Netlify Function — Proxy TomTicket API v2.0
exports.handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json",
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers, body: "" };
  if (event.httpMethod !== "POST") return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };

  let body;
  try { body = JSON.parse(event.body); }
  catch (e) { return { statusCode: 400, headers, body: JSON.stringify({ error: "Invalid JSON" }) }; }

  const { token, endpoint, method = "GET", params = {}, fetchAll = false, maxPages = 20 } = body;
  if (!token || !endpoint) return { statusCode: 400, headers, body: JSON.stringify({ error: "token e endpoint obrigatorios" }) };

  const BASE = "https://api.tomticket.com/v2.0";

  async function fetchPage(p) {
    let url = `${BASE}/${endpoint}`;
    let opts = { method, headers: { "Authorization": "Bearer " + token } };
    if (method === "GET" && Object.keys(p).length > 0) url += "?" + new URLSearchParams(p).toString();
    if (method === "POST") {
      opts.headers["Content-Type"] = "application/x-www-form-urlencoded";
      opts.body = new URLSearchParams(p).toString();
    }
    const res = await fetch(url, opts);
    const text = await res.text();
    try { return { ok: res.ok, status: res.status, data: JSON.parse(text) }; }
    catch (e) { return { ok: res.ok, status: res.status, data: { error: true, message: text.slice(0, 200) } }; }
  }

  function extractItems(d) {
    return Array.isArray(d?.data) ? d.data
      : Array.isArray(d?.organizations) ? d.organizations
      : Array.isArray(d?.customers) ? d.customers
      : Array.isArray(d?.tickets) ? d.tickets
      : Array.isArray(d) ? d : [];
  }

  try {
    if (!fetchAll) {
      const r = await fetchPage(params);
      return { statusCode: r.status, headers, body: JSON.stringify(r.data) };
    }

    // Fetch all pages - up to maxPages
    let all = [];
    let page = 1;
    while (page <= maxPages) {
      const r = await fetchPage({ ...params, page });
      if (!r.ok) {
        if (page === 1) return { statusCode: r.status, headers, body: JSON.stringify(r.data) };
        break;
      }
      const items = extractItems(r.data);
      if (items.length === 0) break;
      all = all.concat(items);
      const total = r.data?.total || r.data?.total_records || 0;
      const perPage = r.data?.per_page || r.data?.limit || 20;
      if (items.length < perPage || (total > 0 && all.length >= total)) break;
      page++;
    }
    return { statusCode: 200, headers, body: JSON.stringify({ data: all, total: all.length }) };
  } catch (e) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: e.message }) };
  }
};
