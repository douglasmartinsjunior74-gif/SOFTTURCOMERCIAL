exports.handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json",
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers, body: "" };
  if (event.httpMethod !== "POST") return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };

  let body;
  try { body = JSON.parse(event.body); }
  catch (e) { return { statusCode: 400, headers, body: JSON.stringify({ error: "Invalid JSON" }) }; }

  const { org, project, pat, mode, ids } = body;
  if (!org || !project || !pat)
    return { statusCode: 400, headers, body: JSON.stringify({ error: "org, project e pat sao obrigatorios" }) };

  const token = Buffer.from(":" + pat).toString("base64");
  const authHeader = "Basic " + token;
  const baseUrl = `https://dev.azure.com/${encodeURIComponent(org)}/${encodeURIComponent(project)}`;

  const fields = [
    "System.Id","System.Title","System.State","System.AssignedTo",
    "System.Tags","System.WorkItemType","System.ChangedDate",
    "System.AreaPath","Microsoft.VSTS.Common.Priority"
  ].join(",");

  function mapItem(w) {
    return {
      id: w.id,
      title: w.fields["System.Title"] || "",
      state: w.fields["System.State"] || "",
      type: w.fields["System.WorkItemType"] || "",
      assigned: w.fields["System.AssignedTo"]?.displayName || w.fields["System.AssignedTo"] || "—",
      tags: w.fields["System.Tags"] || "",
      area: (w.fields["System.AreaPath"] || "").split("\\").pop(),
      priority: w.fields["Microsoft.VSTS.Common.Priority"] || "",
      changed: w.fields["System.ChangedDate"] ? new Date(w.fields["System.ChangedDate"]).toLocaleDateString("pt-BR") : "",
      url: `https://dev.azure.com/${org}/${project}/_workitems/edit/${w.id}`,
    };
  }

  try {
    // ── Mode: fetch specific work items by ID (used by task vinculados) ──
    if (mode === "byIds" && Array.isArray(ids) && ids.length > 0) {
      const r = await fetch(`${baseUrl}/_apis/wit/workitems?ids=${ids.join(",")}&fields=${fields}&api-version=7.0`, {
        headers: { "Authorization": authHeader },
      });
      if (!r.ok) return { statusCode: r.status, headers, body: JSON.stringify({ error: `Erro ${r.status}` }) };
      const d = await r.json();
      return { statusCode: 200, headers, body: JSON.stringify((d.value || []).map(mapItem)) };
    }

    // ── Default mode: fetch ALL work items in pipeline states ──
    const STATES = ["New", "Analise", "Análise", "Desenvolvimento", "Teste", "Merge", "Deploy"];
    const statesSQL = STATES.map(s => `'${s}'`).join(",");
    const wiqlQuery = {
      query: `SELECT [System.Id] FROM WorkItems WHERE [System.State] IN (${statesSQL}) ORDER BY [System.State] ASC, [System.ChangedDate] DESC`
    };

    const r1 = await fetch(`${baseUrl}/_apis/wit/wiql?api-version=7.0`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": authHeader },
      body: JSON.stringify(wiqlQuery),
    });
    if (!r1.ok) {
      const txt = await r1.text();
      return { statusCode: r1.status, headers, body: JSON.stringify({ error: `Azure erro ${r1.status}: ${txt.substring(0, 200)}` }) };
    }
    const d1 = await r1.json();
    const allIds = (d1.workItems || []).map(w => w.id).slice(0, 200);
    if (allIds.length === 0) return { statusCode: 200, headers, body: JSON.stringify([]) };

    const r2 = await fetch(`${baseUrl}/_apis/wit/workitems?ids=${allIds.join(",")}&fields=${fields}&api-version=7.0`, {
      headers: { "Authorization": authHeader },
    });
    if (!r2.ok) return { statusCode: r2.status, headers, body: JSON.stringify({ error: `Erro detalhes: ${r2.status}` }) };
    const d2 = await r2.json();
    return { statusCode: 200, headers, body: JSON.stringify((d2.value || []).map(mapItem)) };

  } catch (e) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: "Erro interno: " + e.message }) };
  }
};
