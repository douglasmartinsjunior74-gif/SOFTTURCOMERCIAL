// Proxy Supabase — banco compartilhado entre todos os usuários
const SUPABASE_URL = process.env.SUPABASE_URL || "https://szcwjimircidkvwkgeya.supabase.co";
const SUPABASE_KEY = process.env.SUPABASE_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN6Y3dqaW1pcmNpZGt2d2tnZXlhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg5ODM2NTEsImV4cCI6MjA5NDU1OTY1MX0.BPYkwxwc65IsPs8y7GbewNkP3HgQjKG7Wpdi3FcxD58";

const HEADERS = {
  "apikey": SUPABASE_KEY,
  "Authorization": "Bearer " + SUPABASE_KEY,
  "Content-Type": "application/json",
  "Prefer": "resolution=merge-duplicates,return=minimal",
};

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json",
};

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers: CORS, body: "" };

  try {
    if (event.httpMethod === "GET") {
      const k = event.queryStringParameters?.key;
      if (!k) return { statusCode: 400, headers: CORS, body: JSON.stringify({ error: "key obrigatório" }) };

      const r = await fetch(
        `${SUPABASE_URL}/rest/v1/softtur_store?chave=eq.${encodeURIComponent(k)}&select=valor`,
        { headers: HEADERS }
      );
      const data = await r.json();
      const value = Array.isArray(data) && data[0] ? data[0].valor : null;
      return { statusCode: 200, headers: CORS, body: JSON.stringify({ value }) };
    }

    if (event.httpMethod === "POST") {
      const { key, value } = JSON.parse(event.body || "{}");
      if (!key) return { statusCode: 400, headers: CORS, body: JSON.stringify({ error: "key obrigatório" }) };

      const r = await fetch(`${SUPABASE_URL}/rest/v1/softtur_store`, {
        method: "POST",
        headers: HEADERS,
        body: JSON.stringify({ chave: key, valor: value }),
      });

      if (!r.ok) {
        const err = await r.text();
        return { statusCode: r.status, headers: CORS, body: JSON.stringify({ error: err }) };
      }
      return { statusCode: 200, headers: CORS, body: JSON.stringify({ ok: true }) };
    }

    return { statusCode: 405, headers: CORS, body: JSON.stringify({ error: "Method not allowed" }) };
  } catch (e) {
    return { statusCode: 500, headers: CORS, body: JSON.stringify({ error: e.message }) };
  }
};
