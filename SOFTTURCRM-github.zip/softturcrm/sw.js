const CACHE = "softtur-crm-v1";
const ASSETS = ["/", "/index.html"];

self.addEventListener("install", function(e){
  e.waitUntil(caches.open(CACHE).then(function(c){return c.addAll(ASSETS);}));
  self.skipWaiting();
});
self.addEventListener("activate", function(e){
  e.waitUntil(caches.keys().then(function(keys){
    return Promise.all(keys.filter(function(k){return k!==CACHE;}).map(function(k){return caches.delete(k);}));
  }));
  self.clients.claim();
});
self.addEventListener("fetch", function(e){
  if(e.request.method!=="GET")return;
  // Network-first for API calls
  if(e.request.url.includes("/.netlify/functions")||e.request.url.includes("/functions/")){
    e.respondWith(fetch(e.request).catch(function(){return new Response(JSON.stringify({error:"Offline"}),{headers:{"Content-Type":"application/json"}});}));
    return;
  }
  // Cache-first for static assets
  e.respondWith(caches.match(e.request).then(function(cached){
    var network=fetch(e.request).then(function(res){
      if(res.ok){var c=res.clone();caches.open(CACHE).then(function(cache){cache.put(e.request,c);});}
      return res;
    }).catch(function(){return cached;});
    return cached||network;
  }));
});
